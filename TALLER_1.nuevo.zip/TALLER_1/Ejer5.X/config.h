/* 
 * File:   config.h
 * Author: Victus
 *
 * Created on August 23, 2023, 2:33 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL

void Secuencia00();
void Secuencia01();
void Secuencia02();
void Secuencia03();
void Secuencia04();
void Secuencia05();
void Secuencia06();
void Secuencia07();
void Secuencia08();
void Secuencia09();

#endif	/* CONFIG_H */


