/* 
 * File:   config.h
 * Author: VICTUS
 *
 * Created on 25 de agosto de 2023, 09:35 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 2000000UL

#endif	/* CONFIG_H */

