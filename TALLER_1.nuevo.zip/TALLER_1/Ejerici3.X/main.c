#include <xc.h>
#include "config.h"



void main(void){
    // Configuraci�n de pines de entrada y salida
    TRISD = 0x00;   // Configuramos PORTD como salidas
    TRISAbits.TRISA0 = 1;  // Configuramos RA0 como entrada
    ANSELAbits.ANSA0 = 0;  // Deshabilitamos la funci�n anal�gica en RA0
    TRISAbits.TRISA1 = 1;  // Configuramos RA1 como entrada
    ANSELAbits.ANSA1 = 0;  // Deshabilitamos la funci�n anal�gica en RA1

      while(1){
        // Verificamos las condiciones de entrada
        if(PORTAbits.RA0 == 1 && PORTAbits.RA1 == 0){
             // Si RA0 est� alto y RA1 est� bajo
            LATDbits.LATD0 = 1;
            LATDbits.LATD1 = 0;
            
        }else if(PORTAbits.RA0 == 0 && PORTAbits.RA1 == 1){
            // Si RA0 est� bajo y RA1 est� alto
            LATDbits.LATD0 = 0;
            LATDbits.LATD1 = 1;
            
        }else{
              // Si ambas RA0 y RA1 est�n en el mismo estado (alto o bajo)
            LATDbits.LATD0 = 0;
            LATDbits.LATD1 = 0;
        }

    }       
    return;

   
}
