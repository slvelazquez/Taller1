#include <xc.h>
#include "config.h"
#define te 100
char led;
// Definici�n de pines para los LEDs
#define LED1 PORTBbits.RB0
#define LED2 PORTBbits.RB1
#define LED3 PORTBbits.RB2
#define LED4 PORTBbits.RB3
#define LED5 PORTBbits.RB4
#define LED6 PORTBbits.RB5
#define LED7 PORTBbits.RB6
#define LED8 PORTBbits.RB7

// Funci�n para encender un LED espec�fico
void encenderLED(int led) {
    switch (led) {
        case 1:
            LED1 = 1;
            break;
        case 2:
            LED2 = 1;
            break;
        case 3:
            LED3 = 1;
            break;
        case 4:
            LED4 = 1;
            break;
        case 5:
            LED5 = 1;
            break;
        case 6:
            LED6 = 1;
            break;
        case 7:
            LED7 = 1;
            break;
        case 8:
            LED8 = 1;
            break;
       // default:
            //break;
    }
}

void apagarLEDs() {
    LED1 = 0;
    LED2 = 0;
    LED3 = 0;
    LED4 = 0;
    LED5 = 0;
    LED6 = 0;
    LED7 = 0;
    LED8 = 0;
}

void main(void){
    
      PORTB = 0x00; //ESTAN EN BAJO
      TRISB = 0x0F;

    // Configurar los pines de los LEDs como salida
    TRISBbits.TRISB0 = 0;
    TRISBbits.TRISB1 = 0;
    TRISBbits.TRISB2 = 0;
    TRISBbits.TRISB3 = 0;
    TRISBbits.TRISB4 = 0;   
    TRISBbits.TRISB5 = 0;
    TRISBbits.TRISB6 = 0;
    TRISBbits.TRISB7 = 0;
    
    

    while(1){
        
        // Secuencia ascendente
        encenderLED(1);
       __delay_ms(te);
        encenderLED(2);
      __delay_ms(te);
        encenderLED(3);
      __delay_ms(te);
        encenderLED(4);
     __delay_ms(te);
        encenderLED(5);
       __delay_ms(te);
        encenderLED(6);
      __delay_ms(te);
        encenderLED(7);
       __delay_ms(te);
        encenderLED(8);
      __delay_ms(te);
        
     
    
      //Secuencia descendente
      encenderLED(8);
      __delay_ms(te);
        encenderLED(7);
      __delay_ms(100);
        encenderLED(6);
     __delay_ms(te);
        encenderLED(5);
     __delay_ms(te);
        encenderLED(4);
     __delay_ms(te);
        encenderLED(3);
    __delay_ms(te);
        encenderLED(2);
      __delay_ms(te);
        encenderLED(1);
     __delay_ms(te);
        
     // Apagar todos los LEDs
       apagarLEDs();
    __delay_ms(te);
        
    }
    return;
}



















