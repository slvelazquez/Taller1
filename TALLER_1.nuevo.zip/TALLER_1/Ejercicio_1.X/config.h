/* 
 * File:   config.h
 * Author: VICTUS
 *
 * Created on 20 de agosto de 2023, 12:26 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL


#endif	/* CONFIG_H */

