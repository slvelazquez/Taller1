/* 
 * File:   config.h
 * Author: VICTUS
 *
 * Created on 3 de septiembre de 2023, 03:47 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL


void  ISR();

#endif	/* CONFIG_H */

