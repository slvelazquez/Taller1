#include <xc.h>
#include "config.h"



void main(void){
    
    ANSELB = 0x00; // desabilitar el analogico 
    TRISDbits.TRISD0 = 0; //salida
    TRISBbits.TRISB0 = 1; //entrada
    TRISBbits.TRISB1 = 1; //entrada
    
    while(1){
        
        if(PORTBbits.RB0 == 0){ //para ver el pulsado
            while(PORTBbits.RB0 == 0); //para que no rebote 
            
            //se invierte el estado utilizando el XOR
            LATDbits.LATD0 ^= 1;
            __delay_ms(100);

        }
        if(PORTBbits.RB1 == 0){ //para ver el pulsado
            while(PORTBbits.RB0 == 0); //para que no rebote 
             //se invierte el estado utilizando el XOR
            LATDbits.LATD0 ^= 1;
            __delay_ms(100);

        }
    }
    
    return;
}

