#include <xc.h>

#include "config.h"


// Definiciones de pines para los LEDs
#define RED_LED_1    PORTCbits.RC0
#define YELLOW_LED_1 PORTCbits.RC1
#define GREEN_LED_1  PORTCbits.RC2
#define RED_LED_2    PORTCbits.RC3
#define YELLOW_LED_2 PORTCbits.RC4
#define GREEN_LED_2  PORTCbits.RC5
#define RED_LED_3    PORTCbits.RC6
#define YELLOW_LED_3 PORTCbits.RC7
#define GREEN_LED_3  PORTDbits.RD0

// Funci�n para controlar el sem�foro
void controlSemaforo(int led) {
    // Apagar todos los LEDs
    RED_LED_1 = 0;
    YELLOW_LED_1 = 0;
    GREEN_LED_1 = 0;
    RED_LED_2 = 0;
    YELLOW_LED_2 = 0;
    GREEN_LED_2 = 0;
    RED_LED_3 = 0;
    YELLOW_LED_3 = 0;
    GREEN_LED_3 = 0;
    
    switch (led) {
        case 0: // Rojo en todas las v�as
            RED_LED_1 = 1;
            RED_LED_2 = 1;
            RED_LED_3 = 1;
            break;
        case 1: // Verde en v�a 1, rojo en v�a 2 y 3
            GREEN_LED_1 = 1;
            RED_LED_2 = 1;
            RED_LED_3 = 1;
            break;
        case 2: // Amarillo en v�a 1, rojo en v�a 2 y 3
            YELLOW_LED_1 = 1;
            RED_LED_2 = 1;
            RED_LED_3 = 1;
            break;
        case 3: // Rojo en v�a 1, verde en v�a 2, rojo en v�a 3
            RED_LED_1 = 1;
            GREEN_LED_2 = 1;
            RED_LED_3 = 1;
            break;
        case 4: // Rojo en v�a 1, amarillo en v�a 2, rojo en v�a 3
            RED_LED_1 = 1;
            YELLOW_LED_2 = 1;
            RED_LED_3 = 1;
            break;
        case 5: // Rojo en v�a 1 y 2, verde en v�a 3
            RED_LED_1 = 1;
            RED_LED_2 = 1;
            GREEN_LED_3 = 1;
            break;
        default:
            break;
    }
}

void main(void) {
    // Configuraci�n de pines como salidas
    TRISC = 0x00; // Puerto C como salidas
    TRISD = 0xFE; // RD0 como salida, el resto como entradas 
    
    TRISCbits.TRISC0 = 0;
    TRISDbits.TRISD1 = 0;
    
    // Inicializaci�n
   /*
    RED_LED_1 = 0;
    YELLOW_LED_1 = 0;
    GREEN_LED_1 = 0;
    RED_LED_2 = 0;
    YELLOW_LED_2 = 0;
    GREEN_LED_2 = 0;
    RED_LED_3 = 0;
    YELLOW_LED_3 = 0;
    GREEN_LED_3 = 0;
    */
    while (1) {
        // Control del sem�foro para cada estado
        controlSemaforo(1); // V�a 1 con verde, v�a 2 y 3 con rojo
        __delay_ms(100);   // Mantener durante 3 segundos
        
        controlSemaforo(2); // V�a 1 con amarillo, v�a 2 y 3 con rojo
        __delay_ms(200);   // Mantener durante 1 segundo
        
        controlSemaforo(3); // V�a 2 con verde, v�a 1 y 3 con rojo
        __delay_ms(200);   // Mantener durante 3 segundos
        
        controlSemaforo(4); // V�a 2 con amarillo, v�a 1 y 3 con rojo
        __delay_ms(100);   // Mantener durante 1 segundo
        
        controlSemaforo(5); // V�a 3 con verde, v�a 1 y 2 con rojo
        __delay_ms(200);   // Mantener durante 3 segundos
    }
}
