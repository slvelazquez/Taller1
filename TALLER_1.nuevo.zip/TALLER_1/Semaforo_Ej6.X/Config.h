/* 
 * File:   Config.h
 * Author: VICTUS
 *
 * Created on 21 de agosto de 2023, 10:48 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 2000000UL


#endif	/* CONFIG_H */

