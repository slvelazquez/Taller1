#include <xc.h>
#include "config.h"


char marca=0;

void main(void){
    
   TRISD = 0x00;  // pines del puerto D como salidas
    PORTD = 0x00;// todos los pines del puerto D en estado bajo (0)

    TRISBbits.TRISB0 = 1; // Configuramos B0 como entrada
    ANSELBbits.ANSB0 = 0; // Desabilitar la entrada analoga 
    TRISBbits.TRISB7 = 0;  // Configuramos B7 como entrada
    
    while(1){
        
        if(PORTBbits.RB0 == 0){
            while(PORTBbits.RB0 == 0);
            marca++;
        }
        if(marca==3){
            LATBbits.LATB7 = 1;
            marca=0;
        }
        __delay_ms(200);
    }
    
    return;
}