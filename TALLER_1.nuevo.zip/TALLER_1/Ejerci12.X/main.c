#include <xc.h>
#include "config.h"

// Variables globales
int entrada1, entrada2, operacion, resultado;

void realizarOperacion();


void realizarOperacion() {
    switch (operacion) {
        case 0b000: // Suma
            resultado = entrada1 + entrada2;
            break;
        case 0b001: // Resta
            resultado = entrada1 - entrada2;
            break;
        case 0b010: // Multiplicaci�n
            resultado = entrada1 * entrada2;
            break;
        case 0b011: // Divisi�n
            if (entrada2 != 0) {
                resultado = entrada1 / entrada2;
            } else {
                resultado = 0; // Manejo de divisi�n por cero
            }
            break;
        default:
            resultado = 0; // Operaci�n no v�lida
            break;
    }
}
void main() {
    
    TRISB = 0b00111000; // Configurar RB3, RB4 y RB5 como entradas para controlar la operaci�n
    TRISC = 0x0F; // Configurar RC0-RC3 como entradas para los n�meros de 4 bits
    TRISD = 0; // Configurar PORTD como salida para mostrar el resultado en binario

    while (1) {
        // Leer las entradas digitales
        entrada1 = PORTC & 0x0F; // Leer el primer n�mero de 4 bits desde RC0-RC3
        entrada2 = (PORTC & 0xF0) >> 4; // Leer el segundo n�mero de 4 bits desde RC4-RC7
        operacion = (PORTB & 0b00111000) >> 3; // Leer la operaci�n desde RB3, RB4 y RB5

        // Realizar la operaci�n y guardar el resultado
        realizarOperacion();

        // Mostrar el resultado en LATD
        LATD = resultado;
    }
}