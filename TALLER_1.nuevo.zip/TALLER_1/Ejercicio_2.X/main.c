#include <xc.h>

#include "config.h"
#define te 100

#define LED1 PORTDbits.RD0
#define LED2 PORTDbits.RD1
#define LED3 PORTDbits.RD2
#define LED4 PORTDbits.RD3
#define LED5 PORTDbits.RD4
#define LED6 PORTDbits.RD5
#define LED7 PORTCbits.RC0
#define LED8 PORTCbits.RC1

void encenderLED(int led) {
    switch (led) {
        case 1:
            LED1 = 1;
            break;
        case 2:
            LED2 = 1;
            break;
        case 3:
            LED3 = 1;
            break;
        case 4:
            LED4 = 1;
            break;
        case 5:
            LED5 = 1;
            break;
        case 6:
            LED6 = 1;
            break;
        case 7:
            LED7 = 1;
            break;
        case 8:
            LED8 = 1;
            break;
        default:
            break;
    }
}

void apagarLEDs() {
    LED1 = 0;
    LED2 = 0;
    LED3 = 0;
    LED4 = 0;
    LED5 = 0;
    LED6 = 0;
    LED7 = 0;
    LED8 = 0;
}

void main() {
    // Configurar los pines de los LEDs como salida
    TRISDbits.TRISD0 = 0;
    TRISDbits.TRISD1 = 0;
    TRISDbits.TRISD2 = 0;
    TRISDbits.TRISD3 = 0;
    TRISDbits.TRISD4 = 0;
    TRISDbits.TRISD5 = 0;
    TRISCbits.TRISC0 = 0;
    TRISCbits.TRISC1 = 0;

    while (1) {
        // Secuencia ascendente
        for (int i = 1; i <= 8; i++) {
            encenderLED(i);
         __delay_ms(te);
            apagarLEDs();
        }

        // Secuencia descendente
        for (int i = 8; i >= 1; i--) {
            encenderLED(i);
           __delay_ms(te);
            apagarLEDs();
        }
    }
}