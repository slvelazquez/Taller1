/* 
 * File:   config.h
 * Author: VICTUS
 *
 * Created on 21 de agosto de 2023, 05:11 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL

#endif	/* CONFIG_H */

