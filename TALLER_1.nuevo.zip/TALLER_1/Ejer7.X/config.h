/* 
 * File:   config.h
 * Author: VICTUS
 *
 * Created on 31 de agosto de 2023, 09:50 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL

#endif	/* CONFIG_H */

