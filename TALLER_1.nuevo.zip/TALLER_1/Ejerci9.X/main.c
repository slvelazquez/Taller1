#include <xc.h>
#include "config.h"



//Definir los pines para los LEDs y pulsadores
#define D1 PORTBbits.RB2
#define D2 PORTBbits.RB1
#define D3 PORTBbits.RB0
#define P1 PORTAbits.RA0
#define P2 PORTAbits.RA1
#define P3 PORTAbits.RA2
#define P4 PORTAbits.RA3

void main(void) {
    // Configurar los pines de los LEDs como salidas
    TRISAbits.TRISA0 = 0;
    TRISAbits.TRISA1 = 0;
    TRISAbits.TRISA2 = 0;

    // Configurar los pines de los pulsadores como entradas
    TRISBbits.TRISB0 = 1;
    TRISBbits.TRISB1 = 1;
    TRISBbits.TRISB2 = 1;
    TRISBbits.TRISB3 = 1;

    // Inicializar los LEDs apagados
    D1 = 0;
    D2 = 0;
    D3 = 0;

    while (1) {
        // Verificar si se presion� el pulsador P1
        if (P1 == 1) {
            D1 = 1;
            D2 = 0;
            D3 = 0;
        }

        // Verificar si se presion� el pulsador P2
        if (P2 == 1) {
            D1 = 0;
            D2 = 1;
            D3 = 0;
        }

        // Verificar si se presion� el pulsador P3
        if (P3 == 1) {
            D1 = 0;
            D2 = 0;
            D3 = 1;
        }

        // Verificar si se presion� el pulsador P4
        if (P4 == 1) {
            D1 = 0;
            D2 = 0;
            D3 = 0;
        }
    }
    return;
}




























/*
#define D1 PORTBbits.RB2
//#define D2 PORTBbits.RB1
//#define D3 PORTBbits.RB0
#define P1 PORTAbits.RA0

//#define P2 PORTBbits.RB2
//#define P3 PORTBbits.RB2

void main(void){
    PORTA = 0x00;
    TRISA = 0x3F;
    PORTB = 0;
    //TRISB = 0x00;
    ANSELB=0x00;
    
    while(1){
        if(P1==0){
     __delay_ms(30);
        while(P1==0);
        __delay_ms(30);
         D1=~D1;
        
        }
        
    }
    
    
    
    
    
    return;
}
*/






































/*
// Definir los pines para los LEDs y pulsadores
#define D1 PORTBbits.RB2
#define D2 PORTBbits.RB1
#define D3 PORTBbits.RB0
#define P1 PORTAbits.RA0
#define P2 PORTAbits.RA1
#define P3 PORTAbits.RA2
#define P4 PORTAbits.RA3

void main(void) {
    // Configurar los pines de los LEDs como salidas
    TRISAbits.TRISA0 = 0;
    TRISAbits.TRISA1 = 0;
    TRISAbits.TRISA2 = 0;

    // Configurar los pines de los pulsadores como entradas
    TRISBbits.TRISB0 = 1;
    TRISBbits.TRISB1 = 1;
    TRISBbits.TRISB2 = 1;
    TRISBbits.TRISB3 = 1;

    // Inicializar los LEDs apagados
    D1 = 0;
    D2 = 0;
    D3 = 0;

    while (1) {
        // Verificar si se presion� el pulsador P1
        if (P1 == 1) {
            D1 = 1;
            D2 = 0;
            D3 = 0;
        }

        // Verificar si se presion� el pulsador P2
        if (P2 == 1) {
            D1 = 0;
            D2 = 1;
            D3 = 0;
        }

        // Verificar si se presion� el pulsador P3
        if (P3 == 1) {
            D1 = 0;
            D2 = 0;
            D3 = 1;
        }

        // Verificar si se presion� el pulsador P4
        if (P4 == 1) {
            D1 = 0;
            D2 = 0;
            D3 = 0;
        }
    }
}

/*
// Definir pines
#define P1 PORTAbits.RA0  //PULSADOR 1
#define P2 PORTAbits.RA1  //PULSADOR 2
#define P3 PORTAbits.RA2   //PULSADOR 3
#define P4 PORTAbits.RA3     //PULSADOR 4

#define D1 PORTBbits.RB2   //LED 1
#define D2 PORTBbits.RB1   //LED 2
#define D3 PORTBbits.RB0   //LED 3

void main() {
    
    TRISB=0x00;
    TRISA=0xFF;
    PORTB = 0x00;
    // Configurar puertos como entradas y salidas
    TRISAbits.TRISA0 = 1; // PULSADOR_1 como entrada
    TRISAbits.TRISA1 = 1; // PULSADOR_2 como entrada
    TRISAbits.TRISA2 = 1; // PULSADOR_3 como entrada
    TRISAbits.TRISA3 = 1; // PULSADOR_4 como entrada
    
    TRISBbits.TRISB2 = 0; // LED_1 como salida
    TRISBbits.TRISB1 = 0; // LED_2 como salida
    TRISBbits.TRISB0 = 0; // LED_3 como salida
    
    // Inicializar LEDs apagados
    D1 = 0;
    D2 = 0;
    D3 = 0;
    
    // Bucle principal
    while(1) {
        // Verificar estado de PULSADOR_1
         if (!P1 && D1 == 0) {
            __delay_ms(50); // Debounce
            if (!P1) {
                D1 = 1;
                D2 = 0;
                D3 = 0;
            }
        }
        
        if (!P2 && D2 == 0) {
            __delay_ms(50); // Debounce
            if (!P2) {
                D1 = 0;
                D2 = 1;
                D3 = 0;
            }
        }
        
        if (!P3 && D3 == 0) {
            __delay_ms(50); // Debounce
            if (!P3) {
                D1 = 0;
                D2 = 0;
                D3 = 1;
            }
        }
        
        if (!P4) {
            __delay_ms(50); // Debounce
            if (!P4) {
                D1 = 0;
                D2 = 0;
                D3 = 0;
            }
        }
    }
}
*/