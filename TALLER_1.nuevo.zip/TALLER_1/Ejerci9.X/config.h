/* 
 * File:   congi.h
 * Author: VICTUS
 *
 * Created on 26 de agosto de 2023, 07:19 PM
 */

#ifndef CONGI_H
#define	CONGI_H

#define _XTAL_FREQ 20000000UL

#endif	/* CONGI_H */

